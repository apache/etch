Visual Studio 2005 solution and Visual C++ 8 project files 
to build the CUnit library, example programs, and test program.